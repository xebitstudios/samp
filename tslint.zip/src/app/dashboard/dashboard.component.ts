import { Component, OnInit, HostListener } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  public innerWidth: any;
  pgwidth: String = '';

  constructor(private router: Router, private route: ActivatedRoute) { }

  ngOnInit() {
    this.innerWidth = window.innerWidth;
    this.pgwidth = (this.innerWidth < 600) ? 'hide' : '';
    console.log('this.pgwidth: ' + this.pgwidth);
  }

  goPage(pge) {
    console.log('inside goPage with: ' + pge);
    switch (pge) {
      case 'Test Center':
        this.router.navigate(['/testcenter']);
        break;
      case 'Analytics':
        this.router.navigate(['/analytics']);
        break;
      case 'Profile':
        this.router.navigate(['/profile']);
        break;
    }
  }

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    this.innerWidth = window.innerWidth;
  }
}
