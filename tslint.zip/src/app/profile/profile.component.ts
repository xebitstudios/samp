import { Component, OnInit } from '@angular/core';
import { DataService } from '../service/data.service';
import { FormGroup, FormControl, Validators} from '@angular/forms';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  title = 'Angular 7 Project!';
  emailid;
  formdata;
  // form disabled
  dis1 = false;
  dis2 = false;
  // user details
  user = {
    "fname": "a",
    "lname": "b",
    "ustraddy": "c",
    "ucity": "d",
    "ustate": "e",
    "ucountry": "f",
    "uphone": "g",
    "uemail": "h",
    "uaboutyou": "i"
  };
  // sch details
  sch = {
    "sschaddy": "q",
    "scity": "r",
    "sstate": "j",
    "scountry": "k",
    "scontact": "l",
    "scontactphone": "m",
    "sschphone": "n",
    "semail": "o",
    "sschdetails": "p"
  };
  formData1;
  formData2;

  constructor(private dataService: DataService) { }

  ngOnInit() {
    // this.formdata = new FormGroup({
    //    emailid: new FormControl('angular@gmail.com'),
    //    passwd: new FormControl('abcd1234')
    // });
  }

  editUserProfile(val) {
    console.log('editUserProfile clicked...');
    this.dis1 = true;
  }
  saveUserProfile(formData1) {
    console.log('saveUserProfile clicked with: ', formData1);
  }
  editUserSchoolProfile(val) {
    console.log('editUserSchProfile clicked...');
    this.dis2 = true;
  }
  saveUserSchoolProfile(formData2) {
    console.log('saveUserSchoolProfile clicked with: ', formData2);
  }
  onSubmit(myform, typ) {
    //  this.emailid = data.emailid;
    if (typ === 'user') {
      console.log('Submitting User Profile data: ', myform);
      this.dataService.saveUserForm(myform);
      this.dis1 = false;
    } else if (typ === 'sch') {
      console.log('Submitting School Profile data: ', myform);
      this.dataService.saveSchForm(myform);
      this.dis2 = false;
    }
  }

}
