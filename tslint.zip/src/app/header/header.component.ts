import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, Router, Params} from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  @Input() tab: string;
  tabArray: String[] = [];
  tabs: any[] = [];
  staffid: number;
  classid: number;
  // tggle: String = 'navbar-collapse collapse';

  constructor(private router: Router, private route: ActivatedRoute) {
    // this.route.params.subscribe( params => console.log(params) );
  }

  ngOnInit() {
    console.log('tab is: ' + this.tab);
    this.tabArray = ['', '', '', '', '', '', '', ''];
    this.tabs = [
      {
        name: 'Main Board',
        colr: '#5F9EEE',
        clas: 'fa fa-home fa-1'
      },
      {
        name: 'Test Center',
        colr: '#76C187',
        clas: 'fa fa-gg fa-1'
      },
      {
        name: 'Analytics',
        colr: '#DEB63B',
        clas: 'fa fa-area-chart fa-1'
      },
      {
        name: 'Profile',
        colr: '#9E7DA6',
        clas: 'fa fa-bar-chart fa-1'
      },
      {
        name: 'Contact Us',
        colr: '#3aa3e3!important',
        clas: 'fa fa-archive fa-1'
      },
      {
        name: 'Pricing',
        colr: '#DE797C',
        clas: 'fa fa-newspaper-o fa-lg'
      },
      {
        name: 'Log Out',
        colr: '#bb1287',
        clas: 'fa fa-sign-in fa-1'
      }
    ];
    this.tabArray[parseInt(this.tab, 10) - 1] = 'active';
  }
  getPage(pge) {
    console.log('inside getPage with: ' + pge);
    switch (pge) {
      case 'Main Board':
        this.router.navigate(['/mainboard']);
        break;
      case 'Test Center':
        this.router.navigate(['/testcenter']);
        break;
      case 'Analytics':
        this.router.navigate(['/analytics']);
        break;
      case 'Profile':
        this.router.navigate(['/profile']);
        break;
      case 'Contact Us':
        this.router.navigate(['/contactus']);
        break;
      case 'Pricing':
        this.router.navigate(['/pricing']);
        break;
      case 'Log Out':
        this.router.navigate(['/logout']);
        break;
      case 'default':
        this.router.navigate(['/logout']);
        break;
    }
  }
  // board(): void {
  //   this.router.navigate(['/mainboard']);
  // }

}
