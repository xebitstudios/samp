import { Component, OnInit } from '@angular/core';
import { DataService } from '../service/data.service';

@Component({
  selector: 'app-contactus',
  templateUrl: './contactus.component.html',
  styleUrls: ['./contactus.component.css']
})
export class ContactusComponent implements OnInit {

  countrylist = this.dataService.countrylist;

  constructor(private dataService: DataService) { }

  ngOnInit() {
  }


  // $scope.contactmodal = {
  //     modalShown: false
  // };
  // $scope.modaltext = "";
  // $scope.modalheader = "";

  // $scope.continueExm = function() {
  //   $scope.contactmodal.modalShown = false;
  // };

  // $scope.inContactUs = function() {
  //       console.log('Now in the Contact Us page!');
  // };

  // $scope.inContactUs();

  // $scope.setModalTexts = function(hdr, bdy) {
  //   $scope.modalheader =hdr;
  //   $scope.modaltext = bdy;
  //   $scope.contactmodal.modalShown = true;
  // };

  // $scope.isEmail = function(email) {
  //   var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
  //   return regex.test(email);
  // };

  // $('#fname').on('keyup', function(e) {
  //   if(($('#fname').val() != "") && ($('#fname').val() != null)) {
  //     $('#fname').removeClass('redborder');
  //   }
  // });

  // $('#lname').on('keyup', function(e) {
  //   if(($('#lname').val() != "") && ($('#lname').val() != null)) {
  //     $('#lname').removeClass('redborder');
  //   }
  // });

  // $('#email').on('keyup', function(e) {
  //   if(($('#email').val() != "") && ($('#email').val() != null)) {
  //     $('#email').removeClass('redborder');
  //   }
  // });

  // $('#phone').on('keyup', function(e) {
  //   if(($('#phone').val() != "") && ($('#phone').val() != null)) {
  //     $('#phone').removeClass('redborder');
  //   }
  // });

  // $('#note').on('keyup', function(e) {
  //   if(($('#note').val() != "") && ($('#note').val() != null)) {
  //     $('#note').removeClass('redborder');
  //   }
  // });

  // $scope.sendForm = function() {
  //   LoggingService.postTrack("cc-sendform");
  //   $log.info('Sending form details to server');
  //   if ($('#fname').val() == "") {
  //     $('#fname').addClass('redborder');
  //   } else if ($('#lname').val() == "") {
  //     $('#lname').addClass('redborder');
  //   } else if ($('#email').val() == "") {
  //     $('#email').addClass('redborder');
  //   } else if ($('#phone').val() == "") {
  //     $('#phone').addClass('redborder');
  //   } else if ($('#note').val() == "") {
  //     $('#note').addClass('redborder');
  //   } else if (!$scope.isEmail($('#email').val())) {
  //     $("#email").addClass('redborder');
  //   } else {
  //     var msg = {
  //       username: $scope.userid,
  //       firstname: $('#fname').val(),
  //       lastname: $('#lname').val(),
  //       email: $('#email').val(),
  //       phone: $('#phone').val(),
  //       cname: Date(),
  //       country: $('#country').val(),
  //       jtitle: $('#jtitle').val(),
  //       note: $('#note').val(),
  //       createdAt: 1,
  //       updatedAt: 1
  //     };
  //     console.log('msg is: ');
  //     console.log(msg);
  //     $scope.sendContactInfo(msg);
  //   }

}
