import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-toprow',
  templateUrl: './toprow.component.html',
  styleUrls: ['./toprow.component.css']
})
export class ToprowComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
