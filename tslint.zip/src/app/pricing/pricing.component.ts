import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pricing',
  templateUrl: './pricing.component.html',
  styleUrls: ['./pricing.component.css']
})
export class PricingComponent implements OnInit {
  prices: any[];
  inst: String;
  confirmmodal: any;

  constructor() { }

  ngOnInit() {
    this.inst = 'Check your email for payment instructions within the next 24 hours.';
    this.confirmmodal = {
      modalShown: false,
      upgrade: 'SSCEexams Upgrade Request',
      text: 'Thanks, please check your email for directions.'
  };
    this.prices = [
      {
        name: 'Free',
        price: '0',
        // tslint:disable-next-line:max-line-length
        notes: 'Practice a limited number of real examinations questions covering all 11 major subjects over 4 years (1988, 1989, 1990, 2015), view your study progress and see analytics to showing how well you are progressing in your preparations.',
        btn: 'Free at Sign Up',
        txt: 'Already Free!',
        perks: 'Offers 3 Examinations years from 1988 to 1990',
        note: 'Free after Joining SSCEexams',
        clr: 'ccc'
      },
      {
        name: 'Standard',
        price: '750',
        // tslint:disable-next-line:max-line-length
        notes: 'Practice real examinations questions spanning a period of 10 years (1988, 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996, 2015) over all 11 major subjects, view your study progress and see comprehensive analytics showing how well you are progressing in preparations.',
        btn: 'Upgrade to Standard',
        txt: 'Confirm Standard Upgrade',
        perks: 'Offers 12 Examinations years from 1988 to 1999',
        note: 'CODE is STANDARD1',
        clr: '2ab27b'
      },
      {
        name: 'Premium',
        price: '1500',
        // tslint:disable-next-line:max-line-length
        notes: 'Practice real examinations questions spanning a period of 28 years over all 11 major subjects, view your study progress, see and generate comprehensive analytics and progress reports showing how well you are progressing.',
        btn: 'Upgrade to Premium',
        txt: 'Confirm Premium Upgrade',
        perks: 'Offers All 28 Examinations years from 1988 to 2015',
        note: 'CODE is PREMIUM2',
        clr: 'f6b63f'
      },
      {
        name: 'School',
        price: '500',
        // tslint:disable-next-line:max-line-length
        notes: 'As a member of your school subscription, you can practice all available 28 years of real examinations over all 13 major subjects. View your progress reports and allow your instructors see how well you are preparing and which areas you might need extra help.',
        btn: 'Start a School Trial',
        txt: 'Request School Upgrade',
        perks: 'Offers Examinations years based on school subscription',
        note: 'Please contact your School administartor for the School issued CODE',
        clr: '5D6D7E'
      }
    ];
  }

}
