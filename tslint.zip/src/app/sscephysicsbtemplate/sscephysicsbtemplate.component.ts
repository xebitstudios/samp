import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../service/data.service';

@Component({
  selector: 'app-sscephysicsbtemplate',
  templateUrl: './sscephysicsbtemplate.component.html',
  styleUrls: ['./sscephysicsbtemplate.component.css']
})
export class SscephysicsbtemplateComponent implements OnInit {
  subj: String;
  year: String;
  navbtns: any[];
  qstlen: number;
  qstnum: number;
  qqt: any;
  qsts: any[];

  constructor(private router: Router, private route: ActivatedRoute, private dataSvc: DataService) { }

  ngOnInit() {
    console.log('Subject: ' + this.dataSvc.subj + ', Year: ' + this.dataSvc.year);
    this.subj = this.dataSvc.subj;
    this.year = this.dataSvc.year;
    this.navbtns = [
      {
        btnn: 'First',
        bimg: 'fa fa-fast-backward fa-1'
      },
      {
        btnn: 'Previous',
        bimg: 'fa fa-step-backward fa-1'
      },
      {
        btnn: 'Next',
        bimg: 'fa fa-step-forward fa-1'
      },
      {
        btnn: 'Last',
        bimg: 'fa fa-fast-forward fa-1'
      },
      // {
      //   btnn: 'Start',
      //   bimg: 'fa fa-hourglass-start fa-1'
      // },
      // {
      //   btnn: 'Pause',
      //   bimg: 'fa fa-pause fa-1'
      // },
      // {
      //   btnn: 'Continue',
      //   bimg: 'fa fa-arrow-right fa-1'
      // },
      {
        btnn: 'Save',
        bimg: 'fa fa-cloud fa-1'
      },
      {
        btnn: 'Finish',
        bimg: 'fa fa-stop fa-1'
      },
      {
        btnn: 'Test Center',
        bimg: 'fa fa-gg fa-1'
      }
    ];
    this.qsts = [
      {
        // tslint:disable-next-line: max-line-length
        'qs': '1. Which of the following instruments is suitable for making the most accurate measurement of the internal diameter of a test tube?',
        'opts': {
          'q0': 'A. metre rule',
          'q1': 'B. A pair of callipers',
          'q2': 'C. A micrometer screw gauge',
          'q3': 'D. A tape rule',
          'q4': 'E. A set square'
        },
        'ans': 'B',
        'sel': ''
      },
      {
          // tslint:disable-next-line: max-line-length
          'qs': '2. A particle of mass 2.5 x 10<sup>-6</sup>kg revolving around the earth has a radial acceleration of 4 x 10<sup>7</sup>m/s<sup>2</sup>. What is the centripetal force of the particles?',
          'opts': {
              'q0': 'A. 6.25 x 10<sup>-14</sup>N',
              'q1': 'B. 1.60 x 10<sup>-13</sup>N',
              'q2': 'C. 1.00 x 10<sup>2</sup>N',
              'q3': 'D. 1.00 x 10<sup>2</sup>N',
              'q4': 'E. 2.00 x 10<sup>2</sup>N'
          },
          'ans': 'D',
          'sel': ''
      },
      {
        // tslint:disable-next-line: max-line-length
        'qs': '3. An oscillating pendulum has a velocity of 2 m/s at the equilibrium position O and velocity at same point P. Using the diagram above, calculate the height h of P above O. (Take g = 10 m/s<sup>2</sup>) <br><img src="assets/imgs/physics/phys_1990_sectionb_qst3_1.jpg">',
        'opts': {
          'q0': 'A. 5.0 m',
          'q1': 'B. 2.0 m',
          'q2': 'C. 0.4 m',
          'q3': 'D. 0.2 m',
          'q4': 'E. 0.1 m'
        },
        'ans': 'D',
        'sel': ''
      },
      {
          // tslint:disable-next-line: max-line-length
          'qs': '4. A plane inclined at an angle at 30° to the horizontal has an efficiency of 50%. The force parallel to the plane required to push a load of 120 N uniformly up the plane is',
          'opts': {
              'q0': 'A. 40(3&radic;2) N',
              'q1': 'B. 60 N',
              'q2': 'C. 120 N',
              'q3': 'D. 200 N',
              'q4': 'E. 240 N'
          },
          'ans': 'C',
          'sel': ''
      },
      {
        // tslint:disable-next-line: max-line-length
        'qs': '5. A force F is applied to a body P as shown in the diagram above. If the body P moves through a distance r, which of the following represents the work done? <br><img src="assets/imgs/physics/phys_1990_sectionb_qst9_1.jpg">',
        'opts': {
            'q0': 'A. Fx',
            'q1': 'B. F (<sup>cos&theta;</sup>/<sub>x</sub>)',
            'q2': 'C. Fx tan&theta;',
            'q3': 'D. Fx sin&theta;',
            'q4': 'E. Fx cos&theta;'
        },
        'ans': 'E',
        'sel': ''
      },
      {
        'qs': '41. Which of the following field patterns between two unlike charges is correct?',
        'opts': {
            "q0": "A. <img src='assets/imgs/physics/phys_1990_sectionb_qst41_1.jpg'>",
            "q1": "B. <img src='assets/imgs/physics/phys_1990_sectionb_qst41_2.jpg'>",
            "q2": "C. <img src='assets/imgs/physics/phys_1990_sectionb_qst41_3.jpg'>",
            "q3": "D. <img src='assets/imgs/physics/phys_1990_sectionb_qst41_4.jpg'>",
            "q4": "E. <img src='assets/imgs/physics/phys_1990_sectionb_qst41_5.jpg'>"
        },
        "ans": "A",
        "sel": ""
      }
    ];
    this.setFirstQst();
  }

  setFirstQst() {
    this.qstlen = this.qsts.length;
    if (this.qsts.length > 0) {
      this.qstnum = 1;
      this.qqt = this.qsts[0];
    }
  }
  getLetter(qst, indx) {
    // console.log('getLetter called with: ' + qst + ', index: ' + indx);
    return true;
  }
  getVals(vals) {
    return Object.values(vals);
  }
  optClick(opt, i) {
    console.log('optClick called...');
  }
  getImage(val) {
    return val.replace('assets/imgs/', 'https://s3.amazonaws.com/ssceexamsdata/imgs/');
  }
  btnclick(bttn) {
    console.log('' + bttn + ' Button clicked...');
    switch (bttn) {
      case 'Test Center':
        this.router.navigate(['/testcenter']);
        break;
      case 'First':
        console.log('First Button clicked...');
        this.qqt = this.qsts[0];
        break;
      case 'Previous':
        console.log('Previous Button clicked...');
        if (this.qstnum > 0) {
          this.qstnum = this.qstnum - 1;
          this.qqt = this.qsts[this.qstnum];
        }
        break;
      case 'Next':
        console.log('Next Button clicked...');
        if (this.qstnum < (this.qstlen - 1)) {
          this.qstnum = this.qstnum + 1;
          this.qqt = this.qsts[this.qstnum];
        }
        break;
      case 'Last':
        console.log('Last Button clicked...');
        this.qqt = this.qsts[this.qstlen - 1];
        break;
      case 'Start':
        console.log('Start Button clicked...');
        break;
      case 'Pause':
        console.log('Pause Button clicked...');
        break;
      case 'Continue':
        console.log('Continue Button clicked...');
        break;
      case 'Save':
        console.log('Save Button clicked...');
        break;
      case 'Finish':
        console.log('Finish Button clicked...');
        break;
    }
  }

}
