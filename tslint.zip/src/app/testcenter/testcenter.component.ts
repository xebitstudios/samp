import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
// import { validateConfig } from '@angular/router/src/config';

@Component({
  selector: 'app-testcenter',
  templateUrl: './testcenter.component.html',
  styleUrls: ['./testcenter.component.css']
})
export class TestcenterComponent implements OnInit {
  examsubjects: any[];

  constructor(private router: Router, private route: ActivatedRoute) { }

  ngOnInit() {
    this.examsubjects = [
      {
        name: 'Physics',
        image: 'physics.png',
        href: 'sscetemplate',
        examlist: ['SSCE', 'GCE', 'NECO'],
        availyears: ['1988', '1989', '1990', '2015'],
        bgcolor: '#F4F6F6'
      },
      {
        name: 'Chemistry',
        image: 'chemistry.png',
        href: 'sscetemplate',
        examlist: ['SSCE', 'GCE', 'NECO'],
        availyears: ['1988', '1989', '1990', '2015'],
        bgcolor: '#F4F6F6'
      },
      {
        name: 'Mathematics',
        image: 'mathematics.png',
        href: 'sscetemplate',
        examlist: ['SSCE', 'GCE', 'NECO'],
        availyears: ['1988', '1989', '1990', '2015'],
        bgcolor: '#F4F6F6'
      },
      {
        name: 'Economics',
        image: 'economics.png',
        href: 'sscetemplate',
        examlist: ['SSCE', 'GCE', 'NECO'],
        availyears: ['1988', '1989', '1990', '2015'],
        bgcolor: '#F4F6F6'
      },
      {
        name: 'Biology',
        image: 'biology.png',
        href: 'sscetemplate',
        examlist: ['SSCE', 'GCE', 'NECO'],
        availyears: ['1988', '1989', '1992', '2015'],
        bgcolor: '#F4F6F6'
      },
      {
        name: 'English',
        image: 'english.png',
        href: 'sscetemplate',
        examlist: ['SSCE', 'GCE', 'NECO'],
        availyears: ['1988', '1989', '1990', '2015'],
        bgcolor: '#F4F6F6'
      },
      {
        name: 'Geography',
        image: 'geography.png',
        href: 'sscetemplate',
        examlist: ['SSCE', 'GCE', 'NECO'],
        availyears: ['1988', '1989', '1990', '2015'],
        bgcolor: '#F4F6F6'
      },
      {
        name: 'Literature',
        image: 'literature.png',
        href: 'sscetemplate',
        examlist: ['SSCE', 'GCE', 'NECO'],
        availyears: ['1988', '2015'],
        bgcolor: '#F4F6F6'
      },
      {
        name: 'Commerce',
        image: 'commerce.png',
        href: 'sscetemplate',
        examlist: ['SSCE', 'GCE', 'NECO'],
        availyears: ['1988', '1989', '1990', '2015'],
        bgcolor: '#F4F6F6'
      },
      {
        name: 'AgricSci',
        image: 'agriculture.png',
        href: 'sscetemplate',
        examlist: ['SSCE', 'GCE', 'NECO'],
        availyears: ['1988', '1989', '1990', '2015'],
        bgcolor: '#F4F6F6'
      },
      {
        name: 'Government',
        image: 'government.png',
        href: 'sscetemplate',
        examlist: ['SSCE', 'GCE', 'NECO'],
        availyears: ['1988', '1989', '1990', '2015'],
        bgcolor: '#F4F6F6'
      }
    ];
  }

  gotoExam(subj, url) {
    console.log('gotoExam called for: ' + subj + ' with URL: ' + url);
    console.log('Sscetemplate link for ' + subj + ' clicked!');
    this.router.navigate(['/sscetemplate/' + subj]);
  }

}
