import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { APP_BASE_HREF } from '@angular/common';

import { BootstrapModalModule } from 'ng2-bootstrap-modal';
import { HighchartsChartModule } from "highcharts-angular";

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { TestcenterComponent } from './testcenter/testcenter.component';
import { AnalyticsComponent } from './analytics/analytics.component';
import { ProfileComponent } from './profile/profile.component';
import { ContactusComponent } from './contactus/contactus.component';
import { PricingComponent } from './pricing/pricing.component';
import { SscetemplateComponent } from './sscetemplate/sscetemplate.component';
import { SscephysicsbtemplateComponent } from './sscephysicsbtemplate/sscephysicsbtemplate.component';
import { DataService } from './service/data.service';
import { LogService } from './service/log.service';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { LoginComponent } from './login/login.component';
import { ToprowComponent } from './toprow/toprow.component';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    TestcenterComponent,
    AnalyticsComponent,
    ProfileComponent,
    ContactusComponent,
    PricingComponent,
    SscetemplateComponent,
    SscephysicsbtemplateComponent,
    HeaderComponent,
    FooterComponent,
    LoginComponent,
    ToprowComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    BootstrapModalModule,
    HighchartsChartModule,
    AppRoutingModule
  ],
  providers: [
    DataService,
    LogService,
    {
      provide: APP_BASE_HREF, useValue : '/'
    }
  ],
  entryComponents: [
    LoginComponent
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
