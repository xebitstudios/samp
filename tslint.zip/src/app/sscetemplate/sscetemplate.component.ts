import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService } from '../service/data.service';

@Component({
  selector: 'app-sscetemplate',
  templateUrl: './sscetemplate.component.html',
  styleUrls: ['./sscetemplate.component.css']
})
export class SscetemplateComponent implements OnInit {
  subj: string;
  year: String;
  headings: any;
  q1: any;
  q2: any;

  constructor(private router: Router, private route: ActivatedRoute, private dataSvc: DataService) {}

  ngOnInit() {
    this.year = '1988';
    this.route.params.subscribe(prams => {
      this.subj = prams.subj;
    });
    this.headings = {
      yrslist: [
        { yr: '1988', chos: 'chosen' },
        { yr: '1989', chos: '' },
        { yr: '1990', chos: '' },
        { yr: '2015', chos: '' }
      ]
    };
  }

  gotopartb(val) {
    console.log('gotopartb called with: ' + val);
    this.dataSvc.subj = val;
    this.dataSvc.year = this.year;
    console.log('Subject: ' + this.dataSvc.subj + ', Year: ' + this.dataSvc.year);
    this.router.navigate(['/sscephysicsbtemplate']);
  }
  gotoparta() {
    console.log('gotoparta called with: ');
    // console.log('gotoExam called for: ' + subj + ' with URL: ' + url + ' for Year: ' + this);
  }
  yrclick(yr, indx) {
    console.log('yrclick called with: ', yr);
    this.year = yr;
    this.headings.yrslist.forEach(obj => {
      if (obj.yr === yr) {
        obj.chos = 'chosen';
      } else {
        obj.chos = '';
      }
    });
  }

}
