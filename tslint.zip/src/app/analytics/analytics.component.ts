declare var require: any;
import { Component, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts/highstock';

const IndicatorsCore = require('highcharts/indicators/indicators');
IndicatorsCore(Highcharts);
const IndicatorZigZag = require('highcharts/indicators/zigzag');
IndicatorZigZag(Highcharts);

@Component({
  selector: 'app-analytics',
  templateUrl: './analytics.component.html',
  styleUrls: ['./analytics.component.css']
})
export class AnalyticsComponent implements OnInit {
  recentexams: any;
  toprow: any[];
  examscores: any;
  username: String;
  activeTab: String;
  pgwidth: true;
  currentpage: Number;
  chartchange: String;

  chart1Subject: String;
  chart1Year: String;
  chart2Subject: String;
  chart2Year: String;
  chart3Year: String;
  chart4Year: String;
  chart5Subject: String;
  chart6Subject: String;

  chart1Data: any;
  chart2Data: any;
  chart3Data: any;
  chart4Data: any;
  chart5Data: any;
  chart6Data: any;
  categories: String[];
  subjlist: any[];
  subjnumber: any[];
  subjmonth: any[];
  subjyear: any[];
  hide: any[];

  constructor() { }

  ngOnInit() {
    console.log('Now in the Analytics page!');
    this.recentexams = {
      subjscores: [
        {
          subj: 'Economics 1995',
          score: '92',
          tim: '12-05-2017 4.36p.m',
          colr: 'mini-notice-warning'
        },
        {
          subj: 'Geography 1989',
          score: '95',
          tim: '07-02-2017 3.29a.m',
          colr: 'mini-notice-info'
        },
        {
          subj: 'Physics 1994',
          score: '89',
          tim: '05-23-2016 8.33p.m',
          colr: 'mini-notice-success'
        },
        {
          subj: 'English 1989',
          score: '73',
          tim: '04-10-2016 11.32a.m',
          colr: 'mini-notice-success'
        },
        {
          subj: 'Biology 1993',
          score: '32',
          tim: '04-10-2016 2.12p.m',
          colr: 'mini-notice-danger'
        }
      ]
    };
    this.toprow = [];
    this.examscores = {};

    this.chart1Data = {};
    this.chart2Data = {};
    this.chart3Data = {};
    this.chart4Data = {};
    this.chart5Data = {};
    this.chart6Data = {};

    this.activeTab = 'usersInProgress';
    this.pgwidth = true;
    this.currentpage = 1;
    this.chartchange = '';
    this.username = 'TJ'; // ConfigService.getUserId();
    console.log('user is: ' + this.username);

    this.chart1Subject = '';
    this.chart1Year = '';
    this.chart2Subject = '';
    this.chart2Year = '';
    this.chart3Year = '';
    this.chart4Year = '';
    this.chart5Subject = '';
    this.chart6Subject = '';
    this.hide = [
      { hideval: '' },
      { hideval: '' },
      { hideval: '' },
      { hideval: '' },
      { hideval: '' },
      { hideval: '' },
      { hideval: '' },
      { hideval: '' },
      { hideval: '' },
      { hideval: '' }
    ];

    this.subjyear = [
      { code: '', name: 'Year' },
      { code: '1988', name: '1988' },
      { code: '1989', name: '1989' },
      { code: '1990', name: '1990' },
      { code: '1991', name: '1991' },
      { code: '1992', name: '1992' },
      { code: '1993', name: '1993' },
      { code: '1994', name: '1994' },
      { code: '1995', name: '1995' },
      { code: '1996', name: '1996' },
      { code: '1997', name: '1997' },
      { code: '1998', name: '1998' },
      { code: '1999', name: '1999' },
      { code: '2000', name: '2000' },
      { code: '2001', name: '2001' },
      { code: '2002', name: '2002' },
      { code: '2003', name: '2003' },
      { code: '2004', name: '2004' },
      { code: '2005', name: '2005' },
      { code: '2006', name: '2006' },
      { code: '2007', name: '2007' },
      { code: '2008', name: '2008' },
      { code: '2009', name: '2009' },
      { code: '2010', name: '2010' },
      { code: '2011', name: '2011' },
      { code: '2012', name: '2012' },
      { code: '2013', name: '2013' },
      { code: '2014', name: '2014' },
      { code: '2015', name: '2015' }
    ];
    this.subjlist = [
      { code: '', name: 'Subject' },
      { code: 'Physics', name: 'Physics' },
      { code: 'Chemistry', name: 'Chemistry' },
      { code: 'Mathematics', name: 'Mathematics' },
      { code: 'Economics', name: 'Economics' },
      { code: 'Biology', name: 'Biology' },
      { code: 'English', name: 'English' },
      { code: 'Geography', name: 'Geography' },
      { code: 'Lit. in English', name: 'Lit. in English' },
      { code: 'Commerce', name: 'Commerce' },
      { code: 'Agric Sci', name: 'Agric Sci' },
      { code: 'Government', name: 'Government' }
    ];
    this.subjnumber = [
      { code: 'Top3', name: 'Top 3' },
      { code: 'Last3', name: 'Last 3' }
    ];
    this.subjmonth = [
      { code: '', name: 'Month' },
      { code: 'Jan', name: 'Jan' },
      { code: 'Feb', name: 'Feb' },
      { code: 'Mar', name: 'Mar' },
      { code: 'Apr', name: 'Apr' },
      { code: 'May', name: 'May' },
      { code: 'Jun', name: 'Jun' },
      { code: 'Jul', name: 'Jul' },
      { code: 'Aug', name: 'Aug' },
      { code: 'Sep', name: 'Sep' },
      { code: 'Oct', name: 'Oct' },
      { code: 'Nov', name: 'Nov' },
      { code: 'Dec', name: 'Dec' }
    ];
    this.categories = [' < 1996', '1996', '1997', '1998',
      '1999', '2000', '2001', '2002', '2003',
      '2004', '2005', '2006', '2007', '2008',
      '2009', '2010', '2011', '2012', '2013',
      '2014', '2015'
    ];

  }

  // var chart = Highcharts.chart('container', { ... });
  Highcharts = Highcharts;
  chartOptions1 = {
    chart: {
        type: 'line'
    },
    title: {
        text: 'Monthly Average Temperature'
    },
    subtitle: {
        text: 'Source: WorldClimate.com'
    },
    xAxis: {
        categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    },
    yAxis: {
        title: {
            text: 'Temperature (°C)'
        }
    },
    plotOptions: {
        line: {
            dataLabels: {
                enabled: true
            },
            enableMouseTracking: false
        }
    },
    series: [{
        name: 'Tokyo',
        data: [7.0, 6.9, 9.5, 14.5, 18.4, 21.5, 25.2, 26.5, 23.3, 18.3, 13.9, 9.6]
    }, {
        name: 'London',
        data: [3.9, 4.2, 5.7, 8.5, 11.9, 15.2, 17.0, 16.6, 14.2, 10.3, 6.6, 4.8]
    }]
  };

  closeme() {
    console.log('closeme clicked...');
  }

}
