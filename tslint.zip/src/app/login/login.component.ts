import { Component, OnInit } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';
import { DataService } from '../service/data.service';
// import { AuthenticationService } from '../services/authentication.service';
import { ActivatedRoute, Router, Params} from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [DataService]
})
export class LoginComponent implements OnInit {
  viz: String[];
  userreg: String;
  userforgot: String;

  constructor(private router: Router,
    private dataSvc: DataService, private route: ActivatedRoute, private meta: Meta, private title: Title) {
      title.setTitle('Portalworks SSCEexams');
      meta.addTags([
        {name: 'name', content: 'Portalworks SSCEexams'},
        {name: 'keywords', content: 'Portalworks, SSCEexams'},
        {name: 'description', content: 'SSCEexams Login'}
      ]);
    }

  ngOnInit() {
    this.router.navigate(['/login']);
    this.viz = ['', 'hide', 'hide', 'hide', 'hide'];
    this.userreg = '';
    this.userforgot = '';
  }

  login() {
    this.router.navigate(['/mainboard']);
  }
  back() {
    console.log('back button clicked...');
    this.viz = ['', 'hide', 'hide', 'hide', 'hide'];
  }
  newuser() {
    console.log('new user button clicked...');
    this.viz = ['hide', 'hide', '', 'hide', 'hide'];
  }
  entercode() {
    console.log('enter code button clicked...');
    this.viz = ['hide', '', 'hide', 'hide', 'hide'];
  }
  forgotpwd() {
    console.log('forgot pwd button clicked...');
    this.viz = ['hide', 'hide', 'hide', '', 'hide'];
  }
  schsignup() {
    console.log('sch sign up button clicked...');
    this.viz = ['', 'hide', 'hide', 'hide', 'hide'];
  }
  confirmcode() {
    console.log('confirmcode clicked...');
  }
  resendconfirmcode() {
    console.log('resendconfirmcode clicked...');
  }
  userRegister() {
    console.log('userRegister clicked...');
  }
  sendForgot() {
    console.log('sendForgot clicked...');
  }

}
